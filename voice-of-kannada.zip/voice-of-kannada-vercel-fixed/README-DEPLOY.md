# Voice of Kannada — Vercel-ready package

This version is arranged so Vercel serves `index.html`, `style.css`, `script.js`, and `config.js` from the **same project root**. This avoids the common mistake of deploying only HTML or setting the root directory to the wrong folder.

## Deploy the fixed colourful frontend

1. Extract this ZIP.
2. In your Vercel project, import/upload this project folder or push its contents to the connected Git repository.
3. In **Project Settings → Build & Development Settings**, use the **Other** framework preset (static site), leave **Root Directory** as `.` / project root, and leave the build command empty. Do not set the root directory to `frontend` for this package; the files are already at the root.
4. Deploy again. A new deployment is required; changing this ZIP on your computer cannot modify the already-live URL automatically.
5. After deployment, open `https://YOUR-DOMAIN/style.css` directly. It should show CSS text, not a 404 page or HTML. Then hard-refresh the home page with Ctrl+Shift+R.

## Why this package is different

- `index.html` is at the project root.
- Stylesheet path is explicit: `./style.css?v=20261015`.
- JavaScript paths are explicit: `./config.js` and `./script.js`.
- `vercel.json` sets safe revalidation headers for CSS/JS so old cached assets are less likely to remain.
- Critical fallback styles are embedded in the HTML so the page retains a colored, structured appearance even if the external CSS request fails.

## Backend

The `backend/` directory contains the FastAPI starter. A static Vercel deployment does **not** run this Python backend automatically. Deploy it separately to a Python/ASGI host, set `FRONTEND_ORIGINS` to your Vercel origin, and set `OPENAI_API_KEY` only in the backend environment if using the AI mentor.

In `config.js`, set `window.VOK_API_BASE` to the real deployed backend origin. Leave it blank until the backend is deployed. Never put a private API key in frontend JavaScript.
