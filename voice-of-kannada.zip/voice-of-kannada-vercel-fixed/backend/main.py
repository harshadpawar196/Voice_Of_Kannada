import os

from dotenv import load_dotenv
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from deep_translator import GoogleTranslator
from openai import OpenAI

load_dotenv()

app = FastAPI(
    title="Voice of Kannada API",
    description="AI-powered Kannada communication assistant",
    version="1.0.0",
)

def configured_origins():
    defaults = [
        "http://127.0.0.1:5500",
        "http://localhost:5500",
        "http://127.0.0.1:5501",
        "http://localhost:5501",
    ]
    extra = os.getenv("FRONTEND_ORIGINS", "")
    return list(dict.fromkeys(defaults + [origin.strip().rstrip("/") for origin in extra.split(",") if origin.strip()]))


# Restrict browser access to local development origins and explicitly configured deployments.
app.add_middleware(
    CORSMiddleware,
    allow_origins=configured_origins(),
    allow_credentials=False,
    allow_methods=["GET", "POST"],
    allow_headers=["Content-Type"],
)

SUPPORTED_LANGUAGES = {
    "en": "English",
    "hi": "Hindi",
    "kn": "Kannada",
}


class TranslationRequest(BaseModel):
    text: str = Field(min_length=1, max_length=500)
    source_language: str
    target_language: str


class ConversationRequest(BaseModel):
    message: str = Field(min_length=1, max_length=1000)
    situation: str = Field(default="general", max_length=50)
    response_language: str = Field(default="en")


@app.get("/")
def home():
    return {
        "message": "Welcome to Voice of Kannada API",
        "status": "running",
    }


@app.get("/api/health")
def health():
    return {
        "status": "healthy",
        "supported_languages": list(SUPPORTED_LANGUAGES.keys()),
    }


@app.post("/api/translate")
def translate_text(request: TranslationRequest):
    text = request.text.strip()
    source = request.source_language.lower()
    target = request.target_language.lower()

    if not text:
        raise HTTPException(status_code=400, detail="Please enter some text.")
    if source not in SUPPORTED_LANGUAGES:
        raise HTTPException(status_code=400, detail="Unsupported source language.")
    if target not in SUPPORTED_LANGUAGES:
        raise HTTPException(status_code=400, detail="Unsupported target language.")
    if source == target:
        raise HTTPException(status_code=400, detail="Choose two different languages.")

    try:
        translator = GoogleTranslator(source=source, target=target)
        translated = translator.translate(text)
        if not translated:
            raise ValueError("Empty translation received.")
        return {
            "original_text": text,
            "translated_text": translated,
            "source_language": source,
            "target_language": target,
        }
    except Exception as exc:
        print("Translation error:", exc)
        raise HTTPException(
            status_code=502,
            detail="Translation service is unavailable. Please try again.",
        )


@app.post("/api/conversation")
def generate_conversation(request: ConversationRequest):
    api_key = os.getenv("OPENAI_API_KEY")
    if not api_key:
        raise HTTPException(
            status_code=503,
            detail="AI conversation is not configured. Add OPENAI_API_KEY to the backend environment.",
        )
    if request.response_language not in SUPPORTED_LANGUAGES:
        raise HTTPException(status_code=400, detail="Unsupported response language.")

    try:
        client = OpenAI(api_key=api_key)
        system_prompt = f"""
You are Voice of Kannada, a helpful Kannada language assistant.
Help non-Kannada speakers communicate in everyday life.
The user's situation is: {request.situation}.
Respond in {SUPPORTED_LANGUAGES[request.response_language]}.
Give a useful response, a natural Kannada phrase when relevant,
a short explanation, and romanized Kannada for beginners.
Be friendly, clear, and concise. Do not claim translations are perfect.
For medical, emergency, legal, or other high-stakes situations,
encourage verification with a qualified person or reliable interpreter.
"""
        response = client.responses.create(
            model="gpt-4.1-mini",
            instructions=system_prompt,
            input=request.message,
        )
        return {
            "response": response.output_text,
            "situation": request.situation,
            "response_language": request.response_language,
        }
    except Exception as exc:
        print("AI conversation error:", exc)
        raise HTTPException(
            status_code=502,
            detail="The AI service could not generate a response. Check the API key, model access, and network, then try again.",
        )
