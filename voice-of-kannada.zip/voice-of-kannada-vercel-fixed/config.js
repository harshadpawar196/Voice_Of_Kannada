/* Configure your deployed backend URL here after deploying the FastAPI backend.
   Example: window.VOK_API_BASE = "https://your-api-service.example.com";
   Keep the URL origin only: do not add /api/translate at the end.
*/
window.VOK_API_BASE = window.VOK_API_BASE || "";
